#!/bin/bash
./loadPeople.sh
./loadProducts.sh
./loadLikes.sh