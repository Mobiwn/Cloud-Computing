package me.foly.microcalc.models;

public enum NodeType {
  OP_PLUS,
  OP_MINUS,
  OP_MULT,
  OP_DIV,
  OP_NEG,
  VAL,
  OP_POW,
  OP_MOD
}
